#! /usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped, Pose
from nav_msgs.msg import Odometry
import casadi as ca
import numpy as np
import tf_transformations

class MPCControllerNode(Node):

    def __init__(self):
        super().__init__('mpc_controller_node')
        self.subscription = self.create_subscription(
            Odometry,
            '/aruco_odometry',
            self.odom_callback,
            10)
        self.cmd_vel_pub = self.create_publisher(TwistStamped, '/jetbot_base_controller/cmd_vel', 10)

        self.current_pose = Pose()
        self.target_pose = Pose()
        self.target_pose.position.x = 1
        self.target_pose.position.y = 0
        self.declare_parameter('T', 1)
        self.declare_parameter('N', 20)
        self.T = self.get_parameter('T').value
        self.N = self.get_parameter('N').value

        self.init_mpc()
        self.control_loop_timer = self.create_timer(self.T, self.control_loop)

    def init_mpc(self):
        # Define the model and MPC problem as shown above
        self.T = 1
        self.N = 20
        x = ca.SX.sym('x')
        y = ca.SX.sym('y')
        theta = ca.SX.sym('theta')
        states = ca.vertcat(x, y, theta)
        n_states = states.size()[0]

        v = ca.SX.sym('v')
        omega = ca.SX.sym('omega')
        controls = ca.vertcat(v, omega)
        n_controls = controls.size()[0]

        rhs = ca.vertcat(v*ca.cos(theta), v*ca.sin(theta), omega)
        self.f = ca.Function('f', [states, controls], [rhs])

        U = ca.SX.sym('U', n_controls, self.N)
        P = ca.SX.sym('P', n_states + n_states)
        X = ca.SX.sym('X', n_states, self.N+1)

        Q = np.diag([10, 10, 0.001])
        R = np.diag([0.5])

        obj = 0
        g = []
        g.append(X[:, 0] - P[:n_states])

        for k in range(self.N):
            st = X[:, k]
            con = U[:, k]
        # Add term to minimize distance to goal
            distance_to_goal = ca.mtimes([(st[0] - P[3])**2, (st[1] - P[4])**2])
            obj += ca.mtimes([(st - P[n_states:]).T, Q, (st - P[n_states:])]) + ca.mtimes([con.T, R, con]) + distance_to_goal
            st_next = X[:, k+1]
            f_value = self.f(st, con)
            st_next_euler = st + self.T * f_value
            g.append(st_next - st_next_euler)

        OPT_variables = ca.vertcat(ca.reshape(X, -1, 1), ca.reshape(U, -1, 1))
        nlp_prob = {
            'f': obj,
            'x': OPT_variables,
            'g': ca.vertcat(*g),
            'p': P
        }

        opts = {
            'ipopt.print_level': 0,
            'ipopt.max_iter': 1000,
            'ipopt.tol': 1e-6,
            'ipopt.acceptable_tol': 1e-8,
            'ipopt.acceptable_obj_change_tol': 1e-6
        }
        self.solver = ca.nlpsol('solver', 'ipopt', nlp_prob, opts)

        self.lbx = ca.DM.zeros((n_states*(self.N+1) + n_controls*self.N, 1))
        self.ubx = ca.DM.zeros((n_states*(self.N+1) + n_controls*self.N, 1))

        self.lbx[0: n_states*(self.N+1): n_states] = -ca.inf
        self.lbx[1: n_states*(self.N+1): n_states] = -ca.inf
        self.lbx[2: n_states*(self.N+1): n_states] = -ca.inf

        self.ubx[0: n_states*(self.N+1): n_states] = ca.inf
        self.ubx[1: n_states*(self.N+1): n_states] = ca.inf
        self.ubx[2: n_states*(self.N+1): n_states] = ca.inf

        self.lbx[n_states*(self.N+1):] = -1
        self.ubx[n_states*(self.N+1):] = 1
        self.lbx[n_states*(self.N+1) + 1::2] = -ca.pi/8
        self.ubx[n_states*(self.N+1) + 1::2] = ca.pi/8

    def odom_callback(self, msg):
        self.current_pose = msg.pose.pose

    def control_loop(self):
        current_x = self.current_pose.position.x
        current_y = self.current_pose.position.y
        current_q = self.current_pose.orientation
        _, _, current_yaw = tf_transformations.euler_from_quaternion([
            current_q.x, current_q.y, current_q.z, current_q.w
        ])

        target_x = self.target_pose.position.x
        target_y = self.target_pose.position.y

        # Compute the distance to the target
        distance_to_target = np.sqrt((target_x - current_x)**2 + (target_y - current_y)**2)

        # Check if the robot is within the threshold of the target position
        if distance_to_target < 0.15:
            twist_msg = TwistStamped()
            twist_msg.header.stamp = self.get_clock().now().to_msg()
            twist_msg.header.frame_id = 'base_link'
            twist_msg.twist.linear.x = 0.0
            twist_msg.twist.angular.y = 0.0
            self.cmd_vel_pub.publish(twist_msg)
            self.get_logger().info('Robot has reached the target. Stopping.')
            return

        p = ca.DM.zeros((6, 1))
        p[0] = current_x
        p[1] = current_y
        p[2] = current_yaw
        p[3] = target_x
        p[4] = target_y
        p[5] = 0  # assuming target orientation is zero

        x0 = ca.DM.zeros((3*(self.N+1), 1))
        u0 = ca.DM.zeros((2*self.N, 1))

        sol = self.solver(
            x0=ca.vertcat(x0, u0),
            lbx=self.lbx,
            ubx=self.ubx,
            lbg=np.zeros((1, 3 * (self.N + 1))),
            ubg=np.zeros((1, 3 * (self.N + 1))),
            p=p
        )

        u_opt = ca.reshape(sol['x'][3*(self.N+1):], 2, self.N)
        twist_msg = TwistStamped()
        twist_msg.header.stamp = self.get_clock().now().to_msg()
        twist_msg.header.frame_id = 'base_link'
        twist_msg.twist.linear.x = float(u_opt[0, 0])
        twist_msg.twist.angular.y = float(u_opt[1, 0])
        self.cmd_vel_pub.publish(twist_msg)
        self.get_logger().info(f"Control commands: linear_x={float(u_opt[0, 0])}, angular_z={float(u_opt[1, 0])}")

def main(args=None):
    rclpy.init(args=args)
    node = MPCControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

