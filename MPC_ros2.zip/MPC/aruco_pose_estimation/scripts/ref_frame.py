#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt

class MarkerDataProcessor:
    def __init__(self, camera_matrix, dist_coeffs, rotation_angle_x, rotation_angle_z):
        self.camera_matrix = camera_matrix
        self.dist_coeffs = dist_coeffs
        self.rotation_angle_x = rotation_angle_x
        self.rotation_angle_z = rotation_angle_z
        self.rotation_matrix_x = self.create_rotation_matrix_x(rotation_angle_x)
        self.rotation_matrix_z = self.create_rotation_matrix_z(rotation_angle_z)
        self.rotation_matrix_combined = np.dot(self.rotation_matrix_z, self.rotation_matrix_x)
        self.marker_positions = {}
        self.origin_marker_id = 4  # Set origin marker ID to 4
        self.fig, self.ax = plt.subplots()

    def create_rotation_matrix_x(self, angle):
        """Create a rotation matrix for a rotation around the x-axis."""
        angle_rad = np.deg2rad(angle)
        return np.array([
            [1, 0, 0],
            [0, np.cos(angle_rad), -np.sin(angle_rad)],
            [0, np.sin(angle_rad), np.cos(angle_rad)]
        ])

    def create_rotation_matrix_z(self, angle):
        """Create a rotation matrix for a rotation around the z-axis."""
        angle_rad = np.deg2rad(angle)
        return np.array([
            [np.cos(angle_rad), -np.sin(angle_rad), 0],
            [np.sin(angle_rad), np.cos(angle_rad), 0],
            [0, 0, 1]
        ])

    def process_marker_data(self, marker_ids, poses):
        # Convert marker poses to 3D positions and adjust for rotation
        for marker_id, pose in zip(marker_ids, poses):
            position = np.array([pose['position']['x'], pose['position']['y'], pose['position']['z']])
            adjusted_position = np.dot(self.rotation_matrix_combined, position)
            self.marker_positions[marker_id] = adjusted_position
        
        # Project 3D positions to 2D
        self.project_positions_to_2d()
        
        # Normalize the reference frame
        self.normalize_reference_frame()

        # Plot results
        self.plot_markers()

    def project_positions_to_2d(self):
        for marker_id, position in self.marker_positions.items():
            z = position[2]  # Assuming z is not zero
            if z > 0:
                x = position[0]
                y = position[1]
                # Compute 2D image coordinates
                x_image = (self.camera_matrix[0, 0] * x + self.camera_matrix[0, 2] * z) / z
                y_image = (self.camera_matrix[1, 1] * y + self.camera_matrix[1, 2] * z) / z
                self.marker_positions[marker_id] = np.array([x_image, y_image])
            else:
                print(f"Skipping marker {marker_id} due to invalid Z value")

    def normalize_reference_frame(self):
        if self.origin_marker_id in self.marker_positions:
            origin_position = self.marker_positions[self.origin_marker_id]
            for marker_id in self.marker_positions:
                self.marker_positions[marker_id] -= origin_position
        else:
            print(f"Origin marker ({self.origin_marker_id}) not found")

    def plot_markers(self):
        self.ax.clear()

        colors = {
            4: 'purple',  # Origin
            0: 'green',   # Corner 1
            5: 'red',     # Corner 2
            6: 'blue'     # Corner 3
        }
        
        for marker_id, position in self.marker_positions.items():
            marker_label = f'Marker {marker_id}'
            marker_color = colors.get(marker_id, 'black')
            self.ax.plot(position[0], position[1], 'o', color=marker_color, label=marker_label)
        
        # Connect markers to visualize the rectangle
        self.connect_markers()

        self.ax.set_xlabel('X Position (pixels)')
        self.ax.set_ylabel('Y Position (pixels)')
        self.ax.set_title('2D Reference Frame of ArUco Markers')
        self.ax.legend()
        self.fig.canvas.draw()
        plt.show()

    def connect_markers(self):
        # Connect markers to visualize the rectangle
        if len(self.marker_positions) == 4:
            # Define the order of markers to connect
            sorted_positions = [self.marker_positions[m_id] for m_id in [4, 2, 5, 0]]
            sorted_positions.append(sorted_positions[0])  # Close the rectangle
            sorted_positions = np.array(sorted_positions)
            self.ax.plot(sorted_positions[:, 0], sorted_positions[:, 1], 'r--')  # Red dashed lines to connect
        else:
            print("Insufficient number of markers to form a rectangle")

# Example usage
if __name__ == "__main__":
    camera_matrix = np.array([
        [1150.517500, 0.000000, 612.895190],
        [0.000000, 1199.805393, 209.723787],
        [0.000000, 0.000000, 1.000000]
    ])
    dist_coeffs = np.array([0.025794, -1.007842, -0.073626, 0.019429, 0.000000])
    
    rotation_angle_x = 10  # Example angle of rotation around the x-axis
    rotation_angle_z = 5   # Example angle of rotation around the z-axis

    marker_ids = [4, 2, 5, 6]  # Updated to match example markers with 4 as origin
    poses = [
        {'position': {'x': 1.222, 'y': 0.287, 'z': 2.569}},  # Marker ID 4 (Origin)
        {'position': {'x': -0.163, 'y': 0.516, 'z': 3.402}}, # Marker ID 5
        {'position': {'x': 1.411, 'y': -1.146, 'z': 3.547}}, # Marker ID 6
        {'position': {'x': -0.173, 'y': -0.946, 'z': 4.483}}  # Marker ID 2
    ]
    
    processor = MarkerDataProcessor(camera_matrix, dist_coeffs, rotation_angle_x, rotation_angle_z)
    processor.process_marker_data(marker_ids, poses)
