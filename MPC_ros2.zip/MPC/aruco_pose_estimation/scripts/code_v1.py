#! /usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped , PoseStamped
from nav_msgs.msg import Odometry
import numpy as np
from numpy import reshape
import math
import numpy.matlib as nmp
from numpy import linalg as LA
import time
from scipy.integrate import odeint
from scipy.optimize import minimize
from casadi import *
import casadi as cs
from aruco_interfaces.msg import ArucoMarkers


class MPCNode(Node):
    def __init__(self):
        super().__init__('move_node')
        
        self.publisher = self.create_publisher(TwistStamped, '/jetbot_base_controller/cmd_vel', 10)
        self.sub3 = self.create_subscription(PoseStamped, '/relative_pose', self.odom2_callback, 10)    

        self.T = 1
        self.N = 200
        self.m = 0.2
        self.M = self.m*(self.m-1)/2
        self.dmin = 0.25
        self.h = 0.2
        
        self.v_max= +0.016
        self.v_min= -self.v_max
        self.omega_max= +0.001
        self.omega_min= -self.omega_max

        self.init_optimizer()

        self.sim_time=2000
        self.t0 =0
        self.x0 = np.array([[0.0], [0.0], [0.0]])
        self.xs= np.array([[+0.0], [+0.0], [+0.0]])
        self.xx = np.zeros((self.n_states, int(self.sim_time/ self.T)))
        self.xx[:, 0:1] = self.x0
        self.t = np.zeros(int(self.sim_time/ self.T))
        self.t[0] = self.t0
        
        self.rob_diam =0.1

        self.u0 = np.zeros((self.n_controls, self.N))
        self.X0 = np.transpose(nmp.repmat(self.x0, 1, self.N + 1))

        self.mpciter = 0
        self.xx1 = np.zeros((self.N + 1, self.n_states, int(self.sim_time/ self.T)))
        self.u_cl = np.zeros((int(self.sim_time/ self.T), self.n_controls))
        self.goal_idx = 1
        self.ng = 10

        self.timer = self.create_timer(self.T, self.main_loop)

        


    def modify(self, th):
        if th >= -math.pi and th < 0:
            th_modified = th + 2 * math.pi
        else:
            th_modified = th
        return th_modified
    
    def shift(self, T, t0, u):
        con = np.transpose(u[0:1, 0:])
        t0 = t0 + T
        ushape = np.shape(u)
        u0 = np.concatenate((u[1:ushape[0], 0:], u[ushape[0] - 1:ushape[0], 0:]), axis=0)
        return t0, u0
    
    # def odom_callback(self, msg):
    #     relative_position = msg.pose.position
    #     relative_orientation = msg.pose.orientation
    #     xr = relative_position.x
    #     yr = relative_position.y
    #     qz = relative_orientation.z
    #     qw = relative_orientation.w
    #     th = 2 * np.arcsin(qz)
    #     thr = self.modify(th)
    #     self.xs = np.array([[xr], [yr], [thr]])
    #     self.get_logger().info(f'Odometry received: x={xr}, y={yr}, theta={thr}')
    # # Do something with the relative pose
    #     print(f"Relative position: {relative_position}")
    #     print(f"Relative orientation: {relative_orientation}")
    
    def odom2_callback(self, msg):
        relative_position = msg.pose.position
        relative_orientation = msg.pose.orientation
        xr = relative_position.x
        yr = relative_position.y
        qz = relative_orientation.z
        qw = relative_orientation.w
        th = 2 * np.arcsin(qz)
        thr = self.modify(th)
        goal_position = np.array([xr, yr])
        

        self.xs = np.array([[xr], [yr], [thr]])
        self.get_logger().info(f'Odometry received: x={xr}, y={yr}, theta={thr}')
    # Do something with the relative pose
        print(f"Relative position: {relative_position}")
        print(f"Relative orientation: {relative_orientation}")
    

    def init_optimizer(self):
        x = SX.sym('x')
        y = SX.sym('y')
        theta = SX.sym('theta')
        self.states = np.array([[x], [y], [theta]])
        self.n_states = len(self.states)

        v = SX.sym('v')
        omega = SX.sym('omega')
        self.controls = np.array([[v], [omega]])
        self.n_controls = len(self.controls)
        rhs = np.array([[v * np.cos(theta)], [v * np.sin(theta)], [omega]])

        self.f = Function('f', [self.states, self.controls], [rhs])

        U = SX.sym('U', self.n_controls, self.N)
        P = SX.sym('P', self.n_states + self.n_states)

        X = SX.sym('X', self.n_states, (self.N + 1))

        obj = 0

        Q = np.zeros((3, 3))
        Q[0, 0] = 1
        Q[1, 1] = 5
        
        R = np.zeros((2, 2))
        R[0, 0] = 0.5
        R[1,1] =  0.05
        v_scale = (self.v_max - self.v_min) / 2
        omega_scale = (self.omega_max - self.omega_min) / 2

# Scaling matrices
        Q_scale = np.diag([1/v_scale, 1/v_scale, 1/omega_scale])
        R_scale = np.diag([1/v_scale, 1/omega_scale])

# Normalized Q and R
        Q_norm = np.dot(np.dot(Q_scale, Q), Q_scale)
        R_norm = np.dot(np.dot(R_scale, R), R_scale)
        st = X[:, 0]

        g = st - P[0:3]
        lambda_ = 0.5
        beta_ = 1 - lambda_
        for k in range(self.N):
            st = X[:, k]
            con = U[:, k]

            obj = obj + mtimes((st - P[3:6]).T, mtimes(Q_norm, (st - P[3:6]))) + mtimes(con.T, mtimes(R_norm, con))

            st_next = X[:, k + 1]
            f_value = self.f(st, con)
            st_next_euler = st + (self.T * f_value)
            g = vertcat(g, st_next - st_next_euler)

        OPT_variables = vertcat(reshape(X, 3 * (self.N + 1), 1), reshape(U, 2 * self.N, 1))
        nlp_prob = {'f': obj, 'x': OPT_variables, 'g': g, 'p': P}

        opts = {'print_time': 0, 'ipopt': {'max_iter': 200, 'print_level': 0, 'acceptable_tol': 1e-8, 'acceptable_obj_change_tol': 1e-6}}
        self.solver = nlpsol('solver', 'ipopt', nlp_prob, opts)

        self.args = {
            'lbg': np.zeros((1, 3 * (self.N + 1))),
            'ubg': np.zeros((1, 3 * (self.N + 1))),
            'lbx': np.concatenate((nmp.repmat(np.array([[-1], [-1], [-1]]), self.N + 1, 1), nmp.repmat(np.array([[self.v_min], [self.omega_min]]), self.N, 1)), axis=0),
            'ubx': np.concatenate((nmp.repmat(np.array([[+1], [+1], [+1]]), self.N + 1, 1), nmp.repmat(np.array([[self.v_max], [self.omega_max]]), self.N, 1)), axis=0)
        }


    # def callback_odom(self, odom):
    #     xr = odom.pose.pose.position.x
    #     yr = odom.pose.pose.position.y
    #     qz = odom.pose.pose.orientation.z
    #     qw = odom.pose.pose.orientation.w
    #     th = 2 * np.arcsin(qz)
    #     thr = self.modify(th)
    #     self.xr = np.array([[xr], [yr], [thr]])

    

    def main_loop(self):
      
        if (LA.norm(self.x0 - self.xs) > 1e-3) and (rclpy.ok()):
            self.get_logger().info('entered in LA.norm if condition')
            self.get_logger().info(f'Current position: {self.x0}')
            self.get_logger().info(f'Target position: {self.xs}')
            self.args['p'] = np.concatenate((self.x0, self.xs), axis=0)
            self.args['x0'] = np.concatenate((reshape(np.transpose(self.X0), 3 * (self.N + 1), 1), reshape(np.transpose(self.u0), 2 * self.N, 1)), axis=0)

            sol = self.solver(x0=self.args['x0'], p=self.args['p'], lbx=self.args['lbx'], ubx=self.args['ubx'], lbg=self.args['lbg'], ubg=self.args['ubg'])

            solu = sol['x'][3 * (self.N + 1):]
            solu_full = np.transpose(solu.full())
            u = np.transpose(reshape(solu_full, 2, self.N))

            solx = sol['x'][0:3 * (self.N + 1)]
            solx_full = np.transpose(solx.full())
            # self.get_logger().info(f'Optimizer state trajectory: {solx_full}')
            # self.get_logger().info(f'Optimizer control input: {solu_full}')            
            # self.xx1[0:, 0:3, self.mpciter] = np.transpose(reshape(solx_full, 3, self.N + 1))

            self.u_cl[self.mpciter, 0:] = u[0:1, 0:]
            
            self.t[self.mpciter] = self.t0
            self.t0, self.u0 = self.shift(self.T, self.t0, u)
            self.x0 = self.xs
            self.xx[0:, self.mpciter + 1:self.mpciter + 2] = self.x0

            solX0 = sol['x'][0:3 * (self.N + 1)]
            solX0_full = np.transpose(solX0.full())
            self.X0 = np.transpose(reshape(solX0_full, 3, self.N + 1))

            self.X0 = np.concatenate((self.X0[1:, 0:self.n_states + 1], self.X0[self.N - 1:self.N, 0:self.n_states + 1]), axis=0)
            
        # Create and publish TwistStamped message
            move = TwistStamped()
            move.header.stamp = self.get_clock().now().to_msg()
            move.twist.linear.x = self.u_cl[self.mpciter, 0]
            move.twist.angular.z = self.u_cl[self.mpciter, 1]
            self.get_logger().info(f'Control input: linear.x = {self.u_cl[self.mpciter, 0]}, angular.z = {self.u_cl[self.mpciter, 1]}')
            self.publisher.publish(move)

        
            self.mpciter += 1
            if self.mpciter == int(self.sim_time/ self.T):
                self.destroy_node()
                move = TwistStamped()
                move.header.stamp = self.get_clock().now().to_msg()
                move.twist.linear.x = 0
                move.twist.angular.z = 0
                self.get_logger().info('Simulation finished')

     # Plot linear velocity
#             axs[0].plot(self.t, self.u_cl[:, 0])
#             axs[0].set_xlabel('Time (s)')
#             axs[0].set_ylabel('Linear Velocity (m/s)')

# # Plot angular velocity
#             axs[1].plot(self.t, self.u_cl[:, 1])
#             axs[1].set_xlabel('Time (s)')
#             axs[1].set_ylabel('Angular Velocity (rad/s)')

#             plt.tight_layout()
#             plt.show()

def main(args=None):
    rclpy.init(args=args)
    mpc_node = MPCNode()
    rclpy.spin(mpc_node)
    mpc_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()