#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import math
from numpy import linalg as LA
# from geometry_msgs.msg import Twist , TwistStamped
from geometry_msgs.msg import Twist , TwistStamped
from nav_msgs.msg import Odometry
from casadi import *
import casadi as cs
from rclpy.duration import Duration
import numpy.matlib as nmp
from aruco_interfaces.msg import ArucoMarkers
from tf2_ros import TransformBroadcaster


def modify(th):
    if th >= -math.pi and th < 0:
        th_modified = th + 2 * math.pi
    else:
        th_modified = th
    return th_modified

def shift(T, t0, u):
    con = np.transpose(u[0:1, 0:])
    t0 = t0 + T
    ushape = np.shape(u)
    u0 = np.concatenate((u[1:ushape[0], 0:], u[ushape[0] - 1:ushape[0], 0:]), axis=0)
    return t0, u0

# Markers Definition
# jetbot always ID 1
# initial point ID 0
# final point   ID 2 
# Obstalces any between 3-9



class MoveNode(Node):
    def __init__(self):
        super().__init__('move_node')
        
        # Initialize subscriber to /tb3_1/odom and publisher to /tb3_1/cmd_vel    jetbot
        # self.sub1 = self.create_subscription(Odometry, '/odom', self.callback_odom, 10)
        self.pub = self.create_publisher(TwistStamped, '/jetbot_base_controller/cmd_vel', 10)

        self.sub2 = self.create_subscription(ArucoMarkers, '/aruco/markers', self.callback_aruco_markers, 10)   # odom subsciber for camera will be usi as jetbot odom
        
        self.tf_broadcaster = TransformBroadcaster(self)
        # turtblebot 
        # self.sub1 = self.create_subscription(Odometry, '/jetbot_base_controller/odom', self.callback_odom, 10)
        # self.pub = self.create_publisher(Twist, '/jetbot_base_controller/cmd_vel', 10)
       
        # Timer for main control loop
        self.timer_period = 0.01  # seconds
        self.timer = self.create_timer(self.timer_period, self.main_loop)
        
        self.T = 1 # [s]
        self.N = 100  # prediction horizon
        self.v_max = +0.016
        self.v_min = -self.v_max
        self.omega_max = +1.00
        self.omega_min = -self.omega_max
        obs1_r = 0.15   # obstacle's diameter
        obs1_x = +1.0
        obs1_y = +0.5

        rob_dim = 0.15
        # Define states and controls for MPC
        x = SX.sym('x')
        y = SX.sym('y')
        theta = SX.sym('theta')
        self.states = np.array([[x], [y], [theta]])
        self.n_states = len(self.states)
        
        v = SX.sym('v')
        omega = SX.sym('omega')
        self.controls = np.array([[v], [omega]])
        self.n_controls = len(self.controls)
        
        rhs = np.array([[v * np.cos(theta)], [v * np.sin(theta)], [omega]])  # system r.h.s
        self.f = Function('f', [self.states, self.controls], [rhs])  # nonlinear mapping function f(x,u)
        
        self.U = SX.sym('U', self.n_controls, self.N)  # Decision variables (controls)
        self.P = SX.sym('P', self.n_states + self.n_states)  # parameters (which include the initial state  the reference state)
        
        self.X = SX.sym('X', self.n_states, (self.N + 1))  # A vector that represents the states over the optimization problem.
        
        self.obj = 0  # Objective function
        Q = np.zeros((3, 3))
        Q[0, 0] = 1
        Q[1, 1] = 1
        Q[2, 2] = 0.1  # weighing matrices (states)
        
        R= np.zeros((2, 2))
        R[0, 0] = 0.5
        R[1, 1] = 0.05  # weighing matrices (controls)
        self.x_max = 5.0
        
       

        st = self.X[:, 0]  # initial state
        self.g = st - self.P[0:3]  # initial condition constraints
        self.lambda_ = 0.9
        self.beta_ = 1 - self.lambda_
        for k in range(self.N):
            st = self.X[:, k]
            con = self.U[:, k]
            #self.obj = self.obj + self.lambda_*sqrt(mtimes((st - self.P[3:6]).T, mtimes(Q, (st - self.P[3:6])))) + self.lambda_*mtimes(con.T, mtimes(R, con))
            self.obj = self.obj + mtimes((st - self.P[3:6]).T, mtimes(Q, (st - self.P[3:6]))) + mtimes(con.T, mtimes(R, con))
            
            st_next = self.X[:, k + 1]
            f_value = self.f(st, con)
            st_next_euler = st + (self.T * f_value)
            self.g = vertcat(self.g, st_next - st_next_euler)
            # self.g = vertcat(self.g, sqrt((self.X[0,k] - obs1_x)**2 + (self.X[1,k] - obs1_y)**2)-rob_dim/2-obs1_r/2)     # obstacle avoidance constraint

        self.OPT_variables = vertcat(reshape(self.X, 3 * (self.N + 1), 1), reshape(self.U, 2 * self.N, 1))
        nlp_prob = {'f': self.obj, 'x': self.OPT_variables, 'g': self.g, 'p': self.P}
        
        opts = {'print_time': 0, 'ipopt': {'max_iter': 2000, 'print_level': 0, 'acceptable_tol': 1e-8, 'acceptable_obj_change_tol': 1e-6}}
        self.solver = nlpsol('solver', 'ipopt', nlp_prob, opts)
        
        self.args ={
            'lbg': np.zeros((1,3*(self.N+1))), 
            'ubg': np.zeros((1,3*(self.N+1))),
            'lbx': np.concatenate((nmp.repmat(np.array([[-10],[-10],[-np.Inf]]),self.N+1,1),nmp.repmat(np.array([[self.v_min],[self.omega_min]]),self.N,1)), axis=0), \
            'ubx':np.concatenate((nmp.repmat(np.array([[+10],[+10],[+np.Inf]]),self.N+1,1),nmp.repmat(np.array([[self.v_max],[self.omega_max]]),self.N,1)), axis=0)
        }
        
        # self.args = {
        #     'lbg': np.concatenate((np.array([[0.0],[0.0],[0.0]]), np.matlib.repmat(np.array([[0.0],[0.0],[0.0],[0.05]]),self.N,1)), axis=0),
        #     'ubg': np.concatenate((np.array([[0.0],[0.0],[0.0]]), np.matlib.repmat(np.array([[0.0],[0.0],[0.0],[np.inf]]),self.N,1)), axis=0),
        #     'lbx': np.concatenate((np.matlib.repmat(np.array([[-10],[-10],[-2*math.pi]]),self.N+1,1),np.matlib.repmat(np.array([[self.v_min],[self.omega_min]]),self.N,1)), axis=0), \
        #     'ubx':np.concatenate((np.matlib.repmat(np.array([[+10],[+10],[+2*math.pi]]),self.N+1,1),np.matlib.repmat(np.array([[self.v_max],[self.omega_max]]),self.N,1)), axis=0)}
        #     # print("args: ", args)
        self.x0 = np.array([[0.0], [0.0], [0.0]])  # Initial condition
        self.xs = np.array([[0.0], [0.0], [0.0]])  # Reference posture
        self.sim_tim = 2000
        self.t0 = 0
        
        self.xx = np.zeros((self.n_states, int(self.sim_tim / self.T)))
        self.xx[:, 0:1] = self.x0  # xx contains the history of states
        self.t = np.zeros(int(self.sim_tim / self.T))
        self.t[0] = self.t0

        self.u0 = np.zeros((self.n_controls, self.N))  # two control inputs for each robot
        self.X0 = np.transpose(repmat(self.x0, 1, self.N + 1))  # initialization of the states decision variables
        # self.Xr = self.x0
        self.Xj = np.array([[0.0], [0.0], [0.0]])
        self.Xg = np.array([[0.0], [0.0], [0.0]])
        self.mpciter = 0
        self.xx1 = np.zeros((self.N + 1, self.n_states, int(self.sim_tim / self.T)))
        self.u_cl = np.zeros((int(self.sim_tim / self.T), self.n_controls))

        self.goal_idx = 0.0
        self.ng = 10
        self.ne = 0
        
        self.marker_dict = {}
        self.x0 = self.Xj  # initial condition.
        # self.xs = np.array([[+3.8282], [+3.3556], [3.785]])  # Reference posture.
        self.xs = self.Xg  # Reference posture.

    # def callback_odom(self, odom):
    #     xr = odom.pose.pose.position.x
    #     yr = odom.pose.pose.position.y
    #     qz = odom.pose.pose.orientation.z
    #     qw = odom.pose.pose.orientation.w
    #     th = 2 * np.arcsin(qz)
    #     thr = modify(th)
    #     self.Xr = np.array([[xr], [yr], [thr]])


    # def callback_jetaruco_markers(self, ArucoMarkers):
    #     for i, marker_id in enumerate(ArucoMarkers.marker_ids):
    #         if marker_id == 0:
    #             pose = ArucoMarkers.poses[i]
    #             xr = pose.position.x
    #             yr = pose.position.y
    #             qz = pose.orientation.z
    #             qw = pose.orientation.w
    #             th = 2 * np.arcsin(qz)
    #             thr = modify(th)
    #             self.Xj = np.array([[xr], [yr], [thr]])

    # def callback_goal_markers(self, ArucoMarkers):
    #     for i, marker_id in enumerate(ArucoMarkers.marker_ids):
    #         if marker_id == 2:
    #             pose = ArucoMarkers.poses[i]
    #             xr = pose.position.x
    #             yr = pose.position.y
    #             qz = pose.orientation.z
    #             qw = pose.orientation.w
    #             th = 2 * np.arcsin(qz)
    #             thr = modify(th)
    #             self.Xg = np.array([[xr], [yr], [thr]])
    
    # def callback_start_markers(self, ArucoMarkers):
    #     for i, marker_id in enumerate(ArucoMarkers.marker_ids):
    #         if marker_id == 0:
    #             pose = ArucoMarkers.poses[i]
    #             xr = pose.position.x
    #             yr = pose.position.y
    #             qz = pose.orientation.z
    #             qw = pose.orientation.w
    #             th = 2 * np.arcsin(qz)
    #             thr = modify(th)
    #             self.Xp = np.array([[xr], [yr], [thr]])

    def callback_aruco_markers(self, msg):
        for i in range(len(msg.marker_ids)):
            marker_id = msg.marker_ids[i]
            self.marker_dict[marker_id] = i

        # Update goal and initial positions
        if 0 in self.marker_dict:
            idx1 = self.marker_dict[1]
            xj = msg.poses[idx1].position.x
            yj = msg.poses[idx1].position.y
            qz = msg.poses[idx1].orientation.z
            qw = msg.poses[idx1].orientation.w
            thj = 2 * np.arcsin(qz)
            thj = modify(thj)
            self.Xj = np.array([[xj], [yj], [thj]])

        if 6 in self.marker_dict:
            idx2 = self.marker_dict[2]
            xg = msg.poses[idx2].position.x
            yg = msg.poses[idx2].position.y
            qz = msg.poses[idx2].orientation.z
            qw = msg.poses[idx2].orientation.w
            thg = 2 * np.arcsin(qz)
            thg = modify(thg)
            self.Xg = np.array([[xg], [yg], [thg]])

        self.get_logger().info(f"Aruco markers updated: Xj={self.Xj}, Xg={self.Xg}")


    def main_loop(self):
        self.get_logger().info('Main loop entered...!')

    
        if (LA.norm(self.x0 - self.xs) > -1) and (rclpy.ok()):
            self.get_logger().info('entered in LA.norm if condition')

            self.args['p'] = np.concatenate((self.x0, self.xs), axis=0)  # set the values of the parameters vector
            self.args['x0'] = np.concatenate((reshape(np.transpose(self.X0), 3 * (self.N + 1), 1), reshape(np.transpose(self.u0), 2 * self.N, 1)), axis=0)

            sol = self.solver(x0=self.args['x0'], p=self.args['p'], lbx=self.args['lbx'], ubx=self.args['ubx'], lbg=self.args['lbg'], ubg=self.args['ubg'])

            solu = sol['x'][3 * (self.N + 1):]
            solu_full = np.transpose(solu.full())
            u = np.transpose(reshape(solu_full, 2, self.N))  # get controls only from the solution

            solx = sol['x'][0:3 * (self.N + 1)]
            solx_full = np.transpose(solx.full())
            self.xx1[0:, 0:3, self.mpciter] = np.transpose(reshape(solx_full, 3, self.N + 1))  # get solution TRAJECTORY

            self.u_cl[self.mpciter, 0:] = u[0:1, 0:]

            self.t[self.mpciter] = self.t0

            # Apply the control and shift the solution
            self.t0, self.u0 = shift(self.T, self.t0, u)
            self.x0 = self.Xj

            self.xx[0:, self.mpciter + 1:self.mpciter + 2] = self.x0

            solX0 = sol['x'][0:3 * (self.N + 1)]
            solX0_full = np.transpose(solX0.full())
            self.X0 = np.transpose(reshape(solX0_full, 3, self.N + 1))  # get solution TRAJECTORY

            # Shift trajectory to initialize the next step
            self.X0 = np.concatenate((self.X0[1:, 0:self.n_states + 1], self.X0[self.N - 1:self.N, 0:self.n_states + 1]), axis=0)

            # Move Robot
            # move = Twist()
            # # move.header.stamp = self.get_clock().now().to_msg()
            # move.linear.x = self.u_cl[self.mpciter, 0]  # apply first optimal linear velocity
            # move.angular.z = self.u_cl[self.mpciter, 1]
            # print("u_cl: ",self.u_cl )
            # self.pub.publish(move)
            # self.get_clock().sleep_for(Duration(seconds=self.T))


            move = TwistStamped()
            move.header.stamp = self.get_clock().now().to_msg()
            move.twist.linear.x = self.u_cl[self.mpciter, 0]  # apply first optimal linear velocity
            move.twist.angular.z = self.u_cl[self.mpciter, 1]
            print("u_cl: ",self.u_cl )
            self.pub.publish(move)
            self.get_clock().sleep_for(Duration(seconds=self.T))
            
            self.mpciter += 1
            # self.ne = LA.norm(self.Xr-self.xs)
            
            
            # rospy.spin()




        # if:
        #     move = Twist()
        #     # move.header.stamp = self.get_clock().now().to_msg()
        #     move.linear.x = 0.0  # apply first optimal linear velocity
        #     move.angular.z = 0.0
        #     self.pub.publish(move)
        #     self.get_logger().info('THE END ...!')
        #  # Move Robot
        #     move = Twist()
        #     move.linear.x = float(self.u_cl[self.mpciter, 0])  # apply first optimal linear velocity
        #     move.angular.z = float(self.u_cl[self.mpciter, 1])
            
        #     twist_stamped_msg = self.twist_to_twist_stamped(move)
        #     self.pub.publish(twist_stamped_msg)
            
        #     self.get_clock().sleep_for(Duration(seconds=self.T))
            
        #     self.mpciter += 1

        else:
            self.get_logger().info('Error encountered')

        move = TwistStamped()
        move.twist.linear.x = 0.0  # apply first optimal linear velocity
        move.twist.angular.z = 0.0
        # twist_stamped_msg = self.twist_to_twist_stamped(move)
        self.pub.publish(move)
        
        self.get_logger().info('THE END ...!')

def main(args=None):
    rclpy.init(args=args)
    move_node = MoveNode()
    rclpy.spin(move_node)
    move_node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()