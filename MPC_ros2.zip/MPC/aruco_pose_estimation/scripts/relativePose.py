#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped, TwistStamped
from nav_msgs.msg import Odometry
import tf2_ros
import numpy as np
import tf_transformations
from aruco_interfaces.msg import ArucoMarkers

class TransformArucoNode(Node):

    def __init__(self):
        super().__init__('transform_aruco_node')
        self.static_tf_broadcaster = tf2_ros.StaticTransformBroadcaster(self)
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        
        self.publish_static_transform()
        
        self.subscription = self.create_subscription(
            ArucoMarkers,
            '/aruco/markers',
            self.marker_pose_callback,
            10)
        
        self.odom_pub = self.create_publisher(Odometry, '/aruco_odometry', 10)
        self.twist_pub = self.create_publisher(TwistStamped, '/cmd_vel', 10)
        self.aruco_marker_2_pose = None

    def publish_static_transform(self):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'camera_link'
        t.child_frame_id = 'world'
        t.transform.translation.x = 1.0 # replace with your values
        t.transform.translation.y = 0.0  # replace with your values
        t.transform.translation.z = 2.8  # replace with your values
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = 0.0
        t.transform.rotation.w = 1.0
        self.static_tf_broadcaster.sendTransform(t)
        
 
        self.get_logger().info("Published static transform for world frame")

    def marker_pose_callback(self, data: ArucoMarkers):
        for i, marker_id in enumerate(data.marker_ids):
            if marker_id == 2:
                self.aruco_marker_2_pose = data.poses[i]
                self.publish_transform(data.poses[i], data.header.frame_id, marker_id)
        
        if self.aruco_marker_2_pose:
            self.compute_and_publish_world_to_marker_2_transform()

    def publish_transform(self, pose, frame_id, marker_id):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = frame_id
        t.child_frame_id = f'aruco_marker_{marker_id}'
        t.transform.translation.x = pose.position.x
        t.transform.translation.y = pose.position.y
        t.transform.translation.z = pose.position.z
        t.transform.rotation.x = pose.orientation.x
        t.transform.rotation.y = pose.orientation.y
        t.transform.rotation.z = pose.orientation.z
        t.transform.rotation.w = pose.orientation.w
        self.tf_broadcaster.sendTransform(t)
        self.get_logger().info(f"Published transform for marker ID {marker_id}")

    def compute_and_publish_world_to_marker_2_transform(self):
        try:
            # Lookup transforms
            transform_world_to_camera = self.tf_buffer.lookup_transform('world', 'camera_link', rclpy.time.Time())
            transform_camera_to_marker_2 = self.tf_buffer.lookup_transform('camera_link', 'aruco_marker_2', rclpy.time.Time())
            
            # Compose the transforms to get world to marker_2
            transform_world_to_marker_2 = self.compose_transform(transform_world_to_camera, transform_camera_to_marker_2)
            
            # Publish the transform
            self.tf_broadcaster.sendTransform(transform_world_to_marker_2)

            # Log the transformation
            self.get_logger().info("Transformation matrix from world frame to Aruco marker 2:")
            self.log_transform(transform_world_to_marker_2)

            # Publish odometry
            self.publish_odometry(transform_world_to_marker_2)

        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
            self.get_logger().warn(f"Could not get transform: {e}")
            
    def publish_world_to_base_link(self):
        try:
            transform_world_to_marker_2 = self.tf_buffer.lookup_transform('world', 'aruco_marker_2_corrected', rclpy.time.Time())
            transform_marker_2_to_base_link = self.tf_buffer.lookup_transform('aruco_marker_2_corrected', 'base_link', rclpy.time.Time())
        
            transform_world_to_base_link = self.compose_transform(transform_world_to_marker_2, transform_marker_2_to_base_link)
            self.tf_broadcaster.sendTransform(transform_world_to_base_link)
            self.get_logger().info("Published transform from world to base_link")

        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
            self.get_logger().warn(f"Could not get transform: {e}")

    def compose_transform(self, transform1, transform2):
        mat1 = self.transform_to_matrix(transform1)
        mat2 = self.transform_to_matrix(transform2)
        composed_mat = np.dot(mat1, mat2)
        return self.matrix_to_transform(composed_mat)

    def transform_to_matrix(self, transform):
        translation = transform.transform.translation
        rotation = transform.transform.rotation
        rotation_matrix = tf_transformations.quaternion_matrix([
            rotation.x, rotation.y, rotation.z, rotation.w
        ])
        rotation_matrix[:3, 3] = [translation.x, translation.y, translation.z]
        return rotation_matrix

    def matrix_to_transform(self, matrix):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'world'
        t.child_frame_id = 'aruco_marker_2_corrected'
        t.transform.translation.x = matrix[0, 3]
        t.transform.translation.y = matrix[1, 3]
        t.transform.translation.z = matrix[2, 3]
        quaternion = tf_transformations.quaternion_from_matrix(matrix)
        t.transform.rotation.x = quaternion[0]
        t.transform.rotation.y = quaternion[1]
        t.transform.rotation.z = quaternion[2]
        t.transform.rotation.w = quaternion[3]
        return t

    def log_transform(self, transform):
        translation = transform.transform.translation
        rotation = transform.transform.rotation
        self.get_logger().info(f"Translation - x: {translation.x}, y: {translation.y}, z: {translation.z}")
        self.get_logger().info(f"Rotation - x: {rotation.x}, y: {rotation.y}, z: {rotation.z}, w: {rotation.w}")

    def publish_odometry(self, transform):
        odom = Odometry()
        odom.header.stamp = self.get_clock().now().to_msg()
        odom.header.frame_id = 'world'
        odom.child_frame_id = 'aruco_marker_2_corrected'
        odom.pose.pose.position.x = transform.transform.translation.x
        odom.pose.pose.position.y = transform.transform.translation.y
        odom.pose.pose.position.z = transform.transform.translation.z
        odom.pose.pose.orientation.x = transform.transform.rotation.x
        odom.pose.pose.orientation.y = transform.transform.rotation.y
        odom.pose.pose.orientation.z = transform.transform.rotation.z
        odom.pose.pose.orientation.w = transform.transform.rotation.w

        # Example covariance values; these should be set according to your system's characteristics
        odom.pose.covariance = [0.01] * 36  # Setting all covariance values to 0.01 for simplicity

        yaw = self.quaternion_to_yaw(transform.transform.rotation)
        self.get_logger().info(f"Yaw angle: {yaw} radians")

        # Update robot's state
        self.Xr = np.array([[odom.pose.pose.position.x], [odom.pose.pose.position.y], [yaw]])
        self.get_logger().info(f"Robot's state updated: Xr = {self.Xr.flatten()}")

        self.odom_pub.publish(odom)
        self.get_logger().info("Published odometry for Aruco marker ID 2")

    def quaternion_to_yaw(self, quaternion):
        """
        Convert a quaternion into a yaw angle (rotation about the Z-axis).

        :param quaternion: geometry_msgs.msg.Quaternion
        :return: yaw angle in radians
        """
        euler = tf_transformations.euler_from_quaternion([
            quaternion.x,
            quaternion.y,
            quaternion.z,
            quaternion.w
        ])
        yaw = euler[2]  # Extract yaw (rotation around Z-axis)
        return yaw

def main(args=None):
    rclpy.init(args=args)
    node = TransformArucoNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

# import rclpy
# from rclpy.node import Node
# from geometry_msgs.msg import Pose, PoseStamped
# from aruco_interfaces.msg import ArucoMarkers
# import numpy as np
# import tf_transformations

# class RelativePoseNode(Node):
#     def __init__(self):
#         super().__init__('relative_pose_node')
#         self.subscription = self.create_subscription(ArucoMarkers, '/aruco/markers', self.listener_callback, 5)
#         self.publisher = self.create_publisher(PoseStamped, '/relative_pose', 5)
#         self.marker1_id = 0 # Replace with desired marker IDs
#         self.marker2_id = 6
        

#     def listener_callback(self, msg):
#         # Find the indices of the desired markers
#         try:
#             marker1_index = msg.marker_ids.index(self.marker1_id)
#             marker2_index = msg.marker_ids.index(self.marker2_id)
#         except ValueError:
#             self.get_logger().warn(f"One or both markers ({self.marker1_id}, {self.marker2_id}) not found")
#             return

#         # Extract marker poses
#         marker1_pose = msg.poses[marker1_index]
#         marker2_pose = msg.poses[marker2_index]
#         self.get_logger().info(f"Marker 6 Pose: {marker1_pose}")
#         self.get_logger().info(f"Marker 2 Pose: {marker2_pose}")
        
#         # Convert poses to transformation matrices
#         T1 = self.pose_to_transform(marker1_pose)
#         T2 = self.pose_to_transform(marker2_pose)

#         # Calculate relative transformation
#         T_rel = np.dot(np.linalg.inv(T1), T2)

#         # Extract relative pose
#         relative_pose = Pose()
#         relative_pose.position.x = T_rel[0, 3]
#         relative_pose.position.y = T_rel[1, 3]
#         relative_pose.position.z = T_rel[2, 3]
#         quaternion = tf_transformations.quaternion_from_matrix(T_rel)
#         relative_pose.orientation.x = quaternion[0]
#         relative_pose.orientation.y = quaternion[1]
#         relative_pose.orientation.z = quaternion[2]
#         relative_pose.orientation.w = quaternion[3]

#         # Publish relative pose
#         relative_pose_msg = PoseStamped()
#         relative_pose_msg.header = msg.header
#         relative_pose_msg.pose = relative_pose
#         self.publisher.publish(relative_pose_msg)

#     def pose_to_transform(self, pose):
#         # Extract position and quaternion
#         translation = np.array([pose.position.x, pose.position.y, pose.position.z])
#         quaternion = [pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w]

#         # Convert quaternion to rotation matrix
#         rotation_matrix = tf_transformations.quaternion_matrix(quaternion)[:3, :3]

#         # Create homogeneous transformation matrix
#         transformation_matrix = np.eye(4)
#         transformation_matrix[:3, :3] = rotation_matrix
#         transformation_matrix[:3, 3] = translation

#         return transformation_matrix
    

# def main(args=None):
#     rclpy.init(args=args)
#     relative_pose_node = RelativePoseNode()
#     rclpy.spin(relative_pose_node)
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()
