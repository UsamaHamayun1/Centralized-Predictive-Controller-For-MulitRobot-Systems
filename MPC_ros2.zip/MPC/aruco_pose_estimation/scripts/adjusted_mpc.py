#!/usr/bin/env python3

# multi robot_simulation
import rclpy
from rclpy.node import Node
import numpy as np
import math
import numpy.matlib
from numpy import linalg as LA
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
import time
from scipy.integrate import odeint
from scipy.optimize import minimize
from casadi import *

class MoveNode(Node):
    def __init__(self):
        super().__init__('move_node')
        self.publisher1 = self.create_publisher(Twist, 'tb3_1/cmd_vel', 10)
        self.publisher2= self.create_publisher(Twist, 'tb3_2/cmd_vel', 10)
        self.subscription1 = self.create_subscription(Odometry, 'tb3_1/odom', self.callback_odom1, 10)
        self.subscription2 = self.create_subscription(Odometry, 'tb3_2/odom', self.callback_odom2, 10)
        self.timer = self.create_timer(0.01, self.main_loop)
        self.dmin = 0.15
        self.rob_diam = 0.1
        self.Xr1 = np.array([[0.0], [0.0], [0.15]])
        self.Xr2 = np.array([[+3.0], [0.0], [0.15]])
        self.x0 = np.array([[0.0], [0.0], [0.0],[0.0], [0.0], [0.0]])
        self.T = 0.1
        self.N = 200
        self.v_max = +0.22
        self.v_min = -self.v_max
        self.omega_max = +2.84
        self.omega_min = -self.omega_max
        self.sim_tim = 3000
        self.t0 = 0
        self.xs = np.array([[+4.0], [+4.0], [0.0],[+1.0], [+4.0], [0.0]])
        self.xx = np.zeros((6, int(self.sim_tim/self.T)))
        self.xx[:, 0:1] = self.x0
        self.t = np.zeros(int(self.sim_tim/self.T))
        self.t[0] = self.t0
        self.u0 = np.zeros((4, self.N))
        self.X0 = np.transpose(np.matlib.repmat(self.x0, 1, self.N+1))
        self.mpciter = 0
        self.xx1 = np.zeros((self.N+1, 6, int(self.sim_tim/self.T)))
        self.u_cl = np.zeros((int(self.sim_tim/self.T), 4))
        
        self.obs_x1 = +1.00
        self.obs_y1 = +1.00

        self.obs_x2 = +2.00
        self.obs_y2 = +1.00


        self.obs1_diam = 0.30
        self.obs2_diam = 0.30
        self.obs1_radius=  self.obs1_diam/2
        self.obs2_radius = self.obs2_diam/2 

        self.init_optimizer()

    def callback_odom1(self, odom):
        xr1 = odom.pose.pose.position.x
        yr1 = odom.pose.pose.position.y
        qz1 = odom.pose.pose.orientation.z
        qw1 = odom.pose.pose.orientation.w
        th1 = 2 * np.arcsin(qz1)
        thr1 = self.modify(th1)
        self.Xr1 = np.array([[xr1], [yr1], [thr1]])
        self.get_logger().info(f"Odometry callback: Xr1 = {self.Xr1.flatten()}")

    def callback_odom2(self, odom):
        xr2 = odom.pose.pose.position.x
        yr2 = odom.pose.pose.position.y
        qz2 = odom.pose.pose.orientation.z
        qw2 = odom.pose.pose.orientation.w
        th2 = 2 * np.arcsin(qz2)
        thr2 = self.modify(th2)
        self.Xr2 = np.array([[xr2], [yr2], [thr2]])
        self.get_logger().info(f"Odometry callback: Xr2 = {self.Xr1.flatten()}")    

    def modify(self, th):
        if th >= -math.pi and th < 0:
            th_modified = th + 2 * math.pi
        else:
            th_modified = th
        return th_modified

    def shift(self, T, t0, u):
        con = np.transpose(u[0:1, 0:])
        t0 = t0 + T
        ushape = np.shape(u)
        u0 = np.concatenate((u[1:ushape[0], 0:], u[ushape[0]-1:ushape[0], 0:]), axis=0)
        return t0, u0

    def init_optimizer(self):
        x1 = SX.sym('x')
        y1 = SX.sym('y')
        theta1 = SX.sym('theta')
        x2 = SX.sym('x')
        y2 = SX.sym('y')
        theta2 = SX.sym('theta')
        states = np.array([[x1], [y1], [theta1],[x2], [y2], [theta2]])
        self.n_states = len(states)

        v1 = SX.sym('v')
        omega1 = SX.sym('omega')
        v2 = SX.sym('v')
        omega2 = SX.sym('omega')
        controls = np.array([[v1], [omega1],[v2], [omega2]])
        self.n_controls = len(controls)
        rhs = np.array([[v1 * np.cos(theta1)], [v1 * np.sin(theta1)], [omega1],[v2 * np.cos(theta2)], [v2 * np.sin(theta2)], [omega2]])

        f = Function('f', [states, controls], [rhs])

        U = SX.sym('U', self.n_controls, self.N)
        P = SX.sym('P', self.n_states + self.n_states)

        X = SX.sym('X', self.n_states, (self.N + 1))

        obj = 0
        Q = np.zeros((self.n_states, self.n_states))
        Q[0, 0] = 1; Q[1, 1] = 10
        Q[3, 3] = 1;Q[4, 4] = 10
        
        R = np.zeros((self.n_controls, self.n_controls))
        R[0, 0] = 0.5; R[1,1] =  0.05
        R[2, 2] = 0.5; R[3,3] =  0.05
        
        v_scale = (self.v_max - self.v_min) / 2
        omega_scale = (self.omega_max - self.omega_min) / 2

# Scaling matrices
#         Q_scale = np.diag([1/v_scale, 1/v_scale, 1/omega_scale])
#         R_scale = np.diag([1/v_scale, 1/omega_scale])

# # Normalized Q and R
#         Q_norm = np.dot(np.dot(Q_scale, Q), Q_scale)
#         R_norm = np.dot(np.dot(R_scale, R), R_scale)
        st = X[:, 0]
        
        lambda_ = 0.5
        beta_ = 1 - lambda_
    
        g = vertcat(st-P[0:6], np.array([3.5]))    
        g = vertcat(st-P[0:6])    
                    
        g = vertcat(st-P[0:self.n_states], np.matlib.repmat(np.array([3.5]), 5, 1)) 
        for k in range(self.N):
            st = X[:, k]
            con = U[:, k]
            d12 = (st[0]-st[3])**2 + (st[1]-st[4])**2
            obj = obj + lambda_*mtimes((st - P[self.n_states:]).T, mtimes(Q, (st - P[self.n_states:]))) + beta_*mtimes(con.T, mtimes(R, con))
            st_next = X[:, k+1]
            f_value = f(st, con)
            st_next_euler = st + (self.T * f_value)
            g = vertcat(g, st_next - st_next_euler)
            g = vertcat(g,d12)
            g = vertcat(g, sqrt((st[0] - self.obs_x1)**2 + (st[1] - self.obs_y1)**2) - self.rob_diam/2 - self.obs1_radius)   #rob1 obs1
            g = vertcat(g, sqrt((st[3] - self.obs_x1)**2 + (st[4] - self.obs_y1)**2) - self.rob_diam/2 - self.obs1_radius)  # rob2 obs1
            g = vertcat(g, sqrt((st[0] - self.obs_x2)**2 + (st[1] - self.obs_y2)**2) - self.rob_diam/2 - self.obs2_radius) # rob1 obs2
            g = vertcat(g, sqrt((st[3] - self.obs_x2)**2 + (st[4] - self.obs_y2)**2) - self.rob_diam/2 - self.obs2_radius) # rob2 obs2

        OPT_variables = vertcat(reshape(X, self.n_states* (self.N + 1), 1), reshape(U, self.n_controls * self.N, 1))
        nlp_prob = {'f': obj, 'x': OPT_variables, 'g': g, 'p': P}

        opts = {'print_time': 0, 'ipopt': {'max_iter': 2000, 'print_level': 0, 'acceptable_tol': 1e-8, 'acceptable_obj_change_tol': 1e-6}}
        self.solver = nlpsol('solver', 'ipopt', nlp_prob, opts)
        
        # self.args = {'lbg': np.matlib.repmat(horzcat(np.zeros((1,6)), np.array([self.dmin*self.dmin])), 1, self.N+1), 'ubg': np.matlib.repmat(horzcat(np.zeros((1,6)), np.array([np.Inf])), 1, self.N+1), \
        #         'lbx': np.concatenate((np.matlib.repmat(np.array([[-10],[-10],[-np.Inf],[-10],[-10],[-np.Inf]]),self.N+1,1),np.matlib.repmat(np.array([[self.v_min],[self.omega_min],[self.v_min],[self.omega_min]]),self.N,1)), axis=0), \
        #         'ubx': np.concatenate((np.matlib.repmat(np.array([[+10],[+10],[+np.Inf],[+10],[+10],[+np.Inf]]),self.N+1,1),np.matlib.repmat(np.array([[self.v_max],[self.omega_max],[self.v_max],[self.omega_max]]),self.N,1)), axis=0)}
        # print("args: ", self.args)
        # Correcting the dimension issue
#         lbg_constraints = np.zeros((self.N + 1, 6))  # 6 dynamic constraints per time step
#         lbg_distance = np.full((self.N + 1, 1), self.dmin * self.dmin)  # 1 distance constraint per time step
#         lbg_obstacle = np.full((self.N + 1, 4),self.dmin*self.dmin)  # 4 obstacle constraints per time step (all set to 0)

#         ubg_constraints = np.zeros((self.N + 1, 6))  # 6 dynamic constraints per time step
#         ubg_distance = np.full((self.N + 1, 1), np.inf)  # 1 distance constraint per time step
#         ubg_obstacle = np.full((self.N + 1, 4), np.inf)   # 4 obstacle constraints per time step (all set to 0)


# # Concatenating all constraints
#         lbg_combined = np.hstack((lbg_constraints, lbg_distance,lbg_obstacle)).flatten()
#         ubg_combined = np.hstack((ubg_constraints, ubg_distance,ubg_obstacle)).flatten()

#         self.args = {
#         'lbg': lbg_combined,  # Should be 706 elements
#         'ubg': ubg_combined,  # Should be 706 elements,
#         'lbx': np.concatenate((
#         np.matlib.repmat(np.array([[-10], [-10], [-np.Inf], [-10], [-10], [-np.Inf]]), self.N + 1, 1),
#         np.matlib.repmat(np.array([[self.v_min], [self.omega_min], [self.v_min], [self.omega_min]]), self.N, 1)
#         ), axis=0),
#         'ubx': np.concatenate((
#         np.matlib.repmat(np.array([[+10], [+10], [+np.Inf], [+10], [+10], [+np.Inf]]), self.N + 1, 1),
#         np.matlib.repmat(np.array([[self.v_max], [self.omega_max], [self.v_max], [self.omega_max]]), self.N, 1)
#         ), axis=0)
#         }
        n_eq_constraints = self.n_states * (self.N + 1)  # Dynamic constraints
        n_ineq_constraints = self.N + 1  # Distance constraints
        n_obs_constraints = 4 * (self.N + 1)  # Obstacle avoidance constraints
        total_constraints = n_eq_constraints + n_ineq_constraints + n_obs_constraints

        lbg = [0] * n_eq_constraints + [self.dmin**2] * n_ineq_constraints + [0] * n_obs_constraints
        ubg = [0] * n_eq_constraints + [np.inf] * n_ineq_constraints + [np.inf] * n_obs_constraints

        lbx = [-10] * self.n_states * (self.N + 1) + [self.v_min, self.omega_min, self.v_min, self.omega_min] * self.N
        ubx = [10] * self.n_states * (self.N + 1) + [self.v_max, self.omega_max, self.v_max, self.omega_max] * self.N

        self.args = {'lbx': lbx, 'ubx': ubx, 'lbg': lbg, 'ubg': ubg}


    def main_loop(self):
        if (LA.norm(self.x0 - self.xs) > 5e-2) and (rclpy.ok()):
            self.args['p'] = np.concatenate((self.x0, self.xs), axis=0)
            self.args['x0'] = np.concatenate((reshape(np.transpose(self.X0), self.n_states* (self.N + 1), 1),
                                              reshape(np.transpose(self.u0), self.n_controls * self.N, 1)), axis=0)

            sol = self.solver(x0=self.args['x0'], p=self.args['p'], lbx=self.args['lbx'],
                              ubx=self.args['ubx'], lbg=self.args['lbg'], ubg=self.args['ubg'])

            solu = sol['x'][self.n_states * (self.N + 1):]
            solu_full = np.transpose(solu.full())
            u = np.transpose(reshape(solu_full, self.n_controls, self.N))

            solx = sol['x'][0:self.n_states * (self.N + 1)]
            solx_full = np.transpose(solx.full())
            self.xx1[0:, 0:self.n_states, self.mpciter] = np.transpose(reshape(solx_full, self.n_states, self.N + 1))

            self.u_cl[self.mpciter, 0:] = u[0:1, 0:]
            self.t[self.mpciter] = self.t0

            self.t0, self.u0 = self.shift(self.T, self.t0, u)
            # self.x0 = self.Xr
            self.x0 = np.concatenate((self.Xr1, self.Xr2), axis=0)
            
            self.xx[0:, self.mpciter+1:self.mpciter+2] = self.x0

            solX0 = sol['x'][0:self.n_states * (self.N + 1)]
            solX0_full = np.transpose(solX0.full())
            self.X0 = np.transpose(reshape(solX0_full, self.n_states, self.N + 1))

            self.X0 = np.concatenate((self.X0[1:, 0:self.n_states], self.X0[self.N-1:self.N, 0:self.n_states]), axis=0)

            # Control commands for robot 1
            move1 = Twist()
            move1.linear.x = self.u_cl[self.mpciter, 0]
            move1.angular.z = self.u_cl[self.mpciter, 1]
            self.publisher1.publish(move1)

        # Control commands for robot 2
            move2 = Twist()
            move2.linear.x = self.u_cl[self.mpciter, 2]
            move2.angular.z = self.u_cl[self.mpciter, 3]
            self.publisher2.publish(move2)

            self.mpciter += 1

        if LA.norm(self.x0 - self.xs) <= 5e-2:
            move1 = Twist()
            move1.linear.x = 0.0
            move1.angular.z = 0.0
            self.publisher1.publish(move1)

            move2 = Twist()
            move2.linear.x = 0.0
            move2.angular.z = 0.0
            self.publisher2.publish(move2)
            
            self.get_logger().info("Goal reached, stopping the robot")
            self.timer.cancel()

def main(args=None):
    rclpy.init(args=args)
    move_node = MoveNode()
    rclpy.spin(move_node)
    move_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
