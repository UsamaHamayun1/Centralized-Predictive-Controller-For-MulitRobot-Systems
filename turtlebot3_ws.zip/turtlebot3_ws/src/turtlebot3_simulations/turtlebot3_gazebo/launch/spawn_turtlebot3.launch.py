import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # Get the TurtleBot3 model from the environment variable
    TURTLEBOT3_MODEL = os.environ.get('TURTLEBOT3_MODEL', 'burger')
    model_folder = 'turtlebot3_' + TURTLEBOT3_MODEL
    urdf_path = os.path.join(
        get_package_share_directory('turtlebot3_gazebo'),
        'models',
        model_folder,
        'model.sdf'
    )

    # Launch configuration variables for each robot's positions
    x_pose_1 = LaunchConfiguration('x_pose_1', default='0.0')
    y_pose_1 = LaunchConfiguration('y_pose_1', default='0.0')

    # Declare the launch arguments
    declare_x_pose_1_cmd = DeclareLaunchArgument(
        'x_pose_1', default_value='0.0', description='X position for robot 1'
    )
    declare_y_pose_1_cmd = DeclareLaunchArgument(
        'y_pose_1', default_value='0.0', description='Y position for robot 1'
    )

    # Start the spawner for Robot 1
    spawn_robot_1 = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'turtlebot3_robot1',  # Unique name for Robot 1
            '-file', urdf_path,
            '-x', x_pose_1,
            '-y', y_pose_1,
            '-z', '0.01',
            '-robot_namespace', 'robot1'
        ],
        output='screen',
    )
    # Create the launch description and add actions
    ld = LaunchDescription()

    # Add the launch options for positions
    ld.add_action(declare_x_pose_1_cmd)
    ld.add_action(declare_y_pose_1_cmd)
  
    # Add the spawning actions for both robots
    ld.add_action(spawn_robot_1)
    

    return ld
