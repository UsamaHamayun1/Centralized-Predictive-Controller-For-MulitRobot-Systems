#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import math
import numpy.matlib
from numpy import linalg as LA
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
import time
from scipy.integrate import odeint
from scipy.optimize import minimize
from casadi import *

class MoveNode(Node):
    def __init__(self):
        super().__init__('move_node')
        self.publisher = self.create_publisher(Twist, '/robot1/cmd_vel', 10)
        self.subscription = self.create_subscription(Odometry, '/robot1/odom', self.callback_odom, 10)
        self.timer = self.create_timer(0.01, self.main_loop)

        self.Xr = np.array([[0.0], [0.0], [0.0]])
        self.x0 = np.array([[0.0], [0.0], [0.0]])
        self.T = 0.2
        self.N = 100
        self.v_max = +0.22
        self.v_min = -self.v_max
        self.omega_max = +2.84
        self.omega_min = -self.omega_max
        self.sim_tim = 3000
        self.t0 = 0
        self.xs = np.array([[+3.0], [+2.0], [0.0]])
        self.xx = np.zeros((3, int(self.sim_tim/self.T)))
        self.xx[:, 0:1] = self.x0
        self.t = np.zeros(int(self.sim_tim/self.T))
        self.t[0] = self.t0
        self.u0 = np.zeros((2, self.N))
        self.X0 = np.transpose(np.matlib.repmat(self.x0, 1, self.N+1))
        self.mpciter = 0
        self.xx1 = np.zeros((self.N+1, 3, int(self.sim_tim/self.T)))
        self.u_cl = np.zeros((int(self.sim_tim/self.T), 2))

        self.obs_x1 = +1.00
        self.obs_y1 = +1.00

        self.obs_x2 = +2.00
        self.obs_y2 = +1.00


        self.obs1_diam = 0.20
        self.obs2_diam = 0.20
        self.obs1_radius=  self.obs1_diam/2
        self.obs2_radius = self.obs2_diam/2 

        self.init_optimizer()

    def callback_odom(self, odom):
        xr = odom.pose.pose.position.x
        yr = odom.pose.pose.position.y
        qz = odom.pose.pose.orientation.z
        qw = odom.pose.pose.orientation.w
        th = 2 * np.arcsin(qz)
        thr = self.modify(th)
        self.Xr = np.array([[xr], [yr], [thr]])
        self.get_logger().info(f"Odometry callback: Xr = {self.Xr.flatten()}")

    def modify(self, th):
        if th >= -math.pi and th < 0:
            th_modified = th + 2 * math.pi
        else:
            th_modified = th
        return th_modified

    def shift(self, T, t0, u):
        con = np.transpose(u[0:1, 0:])
        t0 = t0 + T
        ushape = np.shape(u)
        u0 = np.concatenate((u[1:ushape[0], 0:], u[ushape[0]-1:ushape[0], 0:]), axis=0)
        return t0, u0

    def init_optimizer(self):
        x = SX.sym('x')
        y = SX.sym('y')
        theta = SX.sym('theta')
        states = np.array([[x], [y], [theta]])
        n_states = len(states)

        v = SX.sym('v')
        omega = SX.sym('omega')
        controls = np.array([[v], [omega]])
        n_controls = len(controls)
        rhs = np.array([[v * np.cos(theta)], [v * np.sin(theta)], [omega]])

        f = Function('f', [states, controls], [rhs])

        U = SX.sym('U', n_controls, self.N)
        P = SX.sym('P', n_states + n_states)

        X = SX.sym('X', n_states, (self.N + 1))

        obj = 0
        Q = np.zeros((3, 3))
        Q[0, 0] = 1
        Q[1, 1] = 5
        
        R = np.zeros((2, 2))
        R[0, 0] = 0.5
        R[1,1] =  0.05
        v_scale = (self.v_max - self.v_min) / 2
        omega_scale = (self.omega_max - self.omega_min) / 2

# Scaling matrices
        Q_scale = np.diag([1/v_scale, 1/v_scale, 1/omega_scale])
        R_scale = np.diag([1/v_scale, 1/omega_scale])

# Normalized Q and R
        Q_norm = np.dot(np.dot(Q_scale, Q), Q_scale)
        R_norm = np.dot(np.dot(R_scale, R), R_scale)
        st = X[:, 0]
        # self.obs 
        g = st - P[0:3]
        lambda_ = 0.9
        beta_ = 1 - lambda_
        st = X[:, 0]
        g = st - P[0:3]

        for k in range(self.N):
            st = X[:, k]
            con = U[:, k]
            obj = obj + lambda_*mtimes((st - P[3:6]).T, mtimes(Q, (st - P[3:6]))) + beta_*mtimes(con.T, mtimes(R, con))
            st_next = X[:, k+1]
            f_value = f(st, con)
            st_next_euler = st + (self.T * f_value)
            g = vertcat(g, st_next - st_next_euler)
            g = vertcat(g, sqrt((st[0] - self.obs_x1)**2 + (st[1] - self.obs_y1)**2) - self.rob_diam/2 - self.obs1_radius)   #rob1 obs1
            # g = vertcat(g, sqrt((st[3] - self.obs_x1)**2 + (st[4] - self.obs_y1)**2) - self.rob_diam/2 - self.obs1_radius)  # rob2 obs1
            g = vertcat(g, sqrt((st[0] - self.obs_x2)**2 + (st[1] - self.obs_y2)**2) - self.rob_diam/2 - self.obs2_radius) # rob1 obs2
            # g = vertcat(g, sqrt((st[3] - self.obs_x2)**2 + (st[4] - self.obs_y2)**2) - self.rob_diam/2 - self.obs2_radius) # rob2 obs2

            

        OPT_variables = vertcat(reshape(X, 3 * (self.N + 1), 1), reshape(U, 2 * self.N, 1))
        nlp_prob = {'f': obj, 'x': OPT_variables, 'g': g, 'p': P}

        opts = {'print_time': 0, 'ipopt': {'max_iter': 2000, 'print_level': 0, 'acceptable_tol': 1e-8, 'acceptable_obj_change_tol': 1e-6}}
        self.solver = nlpsol('solver', 'ipopt', nlp_prob, opts)

        self.args = {'lbg': np.concatenate((np.array([[0.0],[0.0],[0.0]]), np.matlib.repmat(np.array([[0.0],[0.0],[0.0],[0.40],[0.40]]),self.N,1)), axis=0), 
                     'ubg': np.concatenate((np.array([[0.0],[0.0],[0.0]]), np.matlib.repmat(np.array([[0.0],[0.0],[0.0],[np.Inf],[np.Inf]]),self.N,1)), axis=0),
                     'lbx': np.concatenate((np.matlib.repmat(np.array([[-10], [-10], [-np.Inf]]), self.N+1, 1),
                                            np.matlib.repmat(np.array([[self.v_min], [self.omega_min]]), self.N, 1)), axis=0),
                     'ubx': np.concatenate((np.matlib.repmat(np.array([[+10], [+10], [+np.Inf]]), self.N+1, 1),
                                            np.matlib.repmat(np.array([[self.v_max], [self.omega_max]]), self.N, 1)), axis=0)}

    def main_loop(self):
        if (LA.norm(self.x0 - self.xs) > 5e-2) and (rclpy.ok()):
            self.args['p'] = np.concatenate((self.x0, self.xs), axis=0)
            self.args['x0'] = np.concatenate((reshape(np.transpose(self.X0), 3 * (self.N + 1), 1),
                                              reshape(np.transpose(self.u0), 2 * self.N, 1)), axis=0)

            sol = self.solver(x0=self.args['x0'], p=self.args['p'], lbx=self.args['lbx'],
                              ubx=self.args['ubx'], lbg=self.args['lbg'], ubg=self.args['ubg'])

            solu = sol['x'][3 * (self.N + 1):]
            solu_full = np.transpose(solu.full())
            u = np.transpose(reshape(solu_full, 2, self.N))

            solx = sol['x'][0:3 * (self.N + 1)]
            solx_full = np.transpose(solx.full())
            self.xx1[0:, 0:3, self.mpciter] = np.transpose(reshape(solx_full, 3, self.N + 1))

            self.u_cl[self.mpciter, 0:] = u[0:1, 0:]
            self.t[self.mpciter] = self.t0

            self.t0, self.u0 = self.shift(self.T, self.t0, u)
            self.x0 = self.Xr

            self.xx[0:, self.mpciter+1:self.mpciter+2] = self.x0

            solX0 = sol['x'][0:3 * (self.N + 1)]
            solX0_full = np.transpose(solX0.full())
            self.X0 = np.transpose(reshape(solX0_full, 3, self.N + 1))

            self.X0 = np.concatenate((self.X0[1:, 0:3], self.X0[self.N-1:self.N, 0:3]), axis=0)

            move = Twist()
            move.linear.x = self.u_cl[self.mpciter, 0]
            move.angular.z = self.u_cl[self.mpciter, 1]
            self.publisher.publish(move)

            self.mpciter += 1

        if LA.norm(self.x0 - self.xs) <= 5e-2:
            move = Twist()
            move.linear.x = 0.0
            move.angular.z = 0.0
            self.publisher.publish(move)
            self.get_logger().info("Goal reached, stopping the robot")
            self.timer.cancel()

def main(args=None):
    rclpy.init(args=args)
    move_node = MoveNode()
    rclpy.spin(move_node)
    move_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
